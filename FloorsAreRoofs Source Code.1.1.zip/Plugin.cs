﻿using System.Collections.Generic;
using System.Reflection;
using BepInEx;
using BepInEx.Logging;
using HarmonyLib;
using UnityEngine;

namespace FloorsAreRoofs
{
	[BepInPlugin(PluginId, FloorsAreRoofsPlugin.ModName, FloorsAreRoofsPlugin.Version)]
	public class FloorsAreRoofsPlugin : BaseUnityPlugin
	{
		private const string PluginId = "bonesbro.val.floorsareroofs";
		public const string Version = "1.0";
		public const string ModName = "Floors Are Roofs";
		Harmony _Harmony;
		public static ManualLogSource Log;
		protected static bool PatchingHasAlreadySucceeded = false;
		internal static bool RemoveRainDamage = true;

		private void Awake()
		{
#if DEBUG
			Log = Logger;
#else
			Log = new ManualLogSource(null);
#endif
			_Harmony = Harmony.CreateAndPatchAll(Assembly.GetExecutingAssembly(), null);
			Config.Bind<int>("General", "NexusID", 1039, "Nexus mod ID for updates");
			RemoveRainDamage = Config.Bind<bool>("General", "RemoveRainDamage", true, "Prevent the floor pieces from taking wear and tear damage from rain.").Value;
		}

		private void OnDestroy()
		{
			_Harmony?.UnpatchAll(PluginId);
		}

		[HarmonyPatch(typeof(ObjectDB), "CopyOtherDB")]
		public static class ObjectDB_CopyOtherDB_Patch
		{
			public static void Postfix()
			{
				FloorsAreRoofsPlugin.PatchFloor();
			}
		}

		internal static void PatchFloor()
		{
			Debug.Log("[floorsareroofs]: Beginning patch attempt");

			// When we first wake up the ObjectDB hasn't been instantiated yet
			if (ObjectDB.instance == null)
			{
				Debug.LogError("[floorsareroofs]: ObjectDB is null");
				return;
			}

			GameObject hammer = ObjectDB.instance.GetItemPrefab("Hammer");
			if (hammer == null)
			{
				Debug.LogError("[floorsareroofs]: Could not find Hammer in ObjectDB");
				return;
			}

			ItemDrop hammerItemDrop;
			if (!hammer.TryGetComponent<ItemDrop>(out hammerItemDrop))
			{
				Debug.LogError("[floorsareroofs]: Could not get itemdrop from hammer");
				return;
			}

			PieceTable hammerPieceTable = hammerItemDrop?.m_itemData?.m_shared?.m_buildPieces;
			if (hammerPieceTable == null)
			{
				Debug.LogError("[floorsareroofs]: Could not find piecetable in hammer");
				return;
			}

			if (hammerPieceTable.m_pieces == null || hammerPieceTable.m_pieces.Count == 0)
			{
				Debug.LogError("[floorsareroofs]: Could not find any pieces in hammerPieceTable");
				return;
			}

			List<GameObject> floors = hammerPieceTable.m_pieces.FindAll(i => i?.name == "wood_floor" || i?.name == "wood_floor_1x1");
			if (floors == null || floors.Count != 2)
			{
				Debug.LogError("[floorsareroofs]: Could not find both expected floors");
				return;
			}

			foreach (GameObject go in floors)
			{
				PatchAFloor(go);
			}

			Debug.Log("[floorsareroofs]: Floors updated successfully!");
		}

		private static void PatchAFloor(GameObject go)
		{
			Debug.Log($"[floorsareroofs]: Preparing to patch {go.name}");

			Transform tr;
			if (!go.TryGetComponent<Transform>(out tr))
			{
				Debug.LogError($"[floorsareroofs]: Could not find Transform in floor {go.name}");
				return;
			}

			WearNTear wn;
			if (!go.TryGetComponent<WearNTear>(out wn))
			{
				Debug.LogError($"[floorsareroofs]: Could not find WearNTear in floor {go.name}");
				return;
			}

			bool foundCollider = false;
			for (int iChild = 0; iChild < tr.childCount; iChild++)
			{
				Transform trChild = tr.GetChild(iChild);

				if (trChild?.name != "collider")
					continue;

				foundCollider = true;
				if (trChild.tag == "leaky")
				{
					trChild.tag = "roof";
					Debug.Log($"[floorsareroofs] Successfully patched {go.name} into a roof");
				}
				else if (trChild.tag == "roof")
				{
					Debug.Log($"[floorsareroofs] {go.name} is already a roof");
				}
				else
				{
					Debug.LogError($"[floorsareroofs]: Could not patch {go.name}.  Its collider has tag '{trChild.tag ?? "[null]"}' instead of 'leaky'");
				}
			}

			if (!foundCollider)
			{
				Debug.LogError($"[floorsareroofs]: Could not find collider in {go.name}");
				return;
			}

			if (RemoveRainDamage)
			{
				if (wn.m_noRoofWear)
				{
					Debug.Log($"[floorsareroofs] {go.name} patched to not degrade in the rain");
					wn.m_noRoofWear = false;
				}
				else
				{
					Debug.Log($"[floorsareroofs] {go.name} already does not degrade in the rain");
				}
			}
			else
			{
				Debug.Log($"[floorsareroofs] Not updating m_noRoofWear because config setting RemoveRainDamage is false");
			}

		}
	}
}
